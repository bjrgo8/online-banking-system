const AboutUs = () => {
  return (
    <div className="text-color ms-5 me-5 mr-5 mt-3">
      <b>This is About Us Component</b>
    </div>
  );
};

export default AboutUs;
