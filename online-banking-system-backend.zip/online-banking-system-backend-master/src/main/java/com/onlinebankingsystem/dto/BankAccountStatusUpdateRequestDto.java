package com.onlinebankingsystem.dto;

public class BankAccountStatusUpdateRequestDto {

	private int accountId;

	private String status;

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
